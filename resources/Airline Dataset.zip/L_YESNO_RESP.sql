INSERT INTO Airline.L_YESNO_RESP (Code,Description) VALUES
	 (0,'No'),
	 (1,'Yes');
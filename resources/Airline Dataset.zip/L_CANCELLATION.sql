INSERT INTO Airline.L_CANCELLATION (Code,Description) VALUES
	 ('A','Carrier'),
	 ('B','Weather'),
	 ('C','National Air System'),
	 ('D','Security');
INSERT INTO Airline.L_QUARTERS (Code,Description) VALUES
	 (1,'Quarter1:January 1-March 31'),
	 (2,'Quarter2:April 1-June 30'),
	 (3,'Quarter3:July 1-September 30'),
	 (4,'Quarter4:October 1-December 31');
INSERT INTO Airline.L_DISTANCE_GROUP_250 (Code,Description) VALUES
	 (1,'Less Than 250 Miles'),
	 (2,'250-499 Miles'),
	 (3,'500-749 Miles'),
	 (4,'750-999 Miles'),
	 (5,'1000-1249 Miles'),
	 (6,'1250-1499 Miles'),
	 (7,'1500-1749 Miles'),
	 (8,'1750-1999 Miles'),
	 (9,'2000-2249 Miles'),
	 (10,'2250-2499 Miles'),
	 (11,'2500 Miles and Greater');